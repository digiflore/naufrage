
let game;

const woodElement = document.getElementById("wood");
const foodElement = document.getElementById("food");
const toolsElement = document.getElementById("tools");
const materialElement = document.getElementById("material");
const moodElement = document.getElementById("mood");
const buildingsElement = document.getElementById("buildings");
const nbActionsElement = document.getElementById("nbActions");

const dayElement = document.getElementById("day");
const dayButtonElement = document.getElementById("dayButton");

const eventContainer = document.getElementById("event-container");
const eventText = document.getElementById("event-text");
const eventChoices = document.getElementById("event-choices");
const eventChoiceText = document.getElementById("event-choice-text");
const actionContainer = document.getElementById("action-container");
const actionLib = document.getElementById("action-lib");
const actionChoices = document.getElementById("action-choices");
const actionValidate = document.getElementById("validate-actions");
const actionSummary = document.getElementById("action-summary");
const consumptionContainer = document.getElementById("consumption-container");
const consumptionText = document.getElementById("consumption-text");
const logDiv = document.getElementById("log");

let maxActions = 3;
let maxMood = 10;
let selectedActions = [];
let nbBuildingsAvailable = 0;

let events = [
  { text: "Un arbre tombe et t'apporte du bois sec.", gains: { wood: 3 }, type: "good", condition: () => true },
  { text: "Tu trouves un buisson plein de fruits.", gains: { food: 3 }, type: "good" },
  { text: "Tu arrive à pêcher du poisson ce matin.", gains: { food: 2 }, type: "good" },
  { text: "Tu trouves du bois sur la plage.", gains: { wood: 2 }, type: "good" },
  { text: "Il y a du soleil aujourd'hui, ça te remonte le moral.", gains: { mood: 1 }, type: "good" },
  { text: "Tu trouves une caisse sur la plage.", gains: { food: 3, wood: 2 }, type: "good" },
  { text: "Un tempête détruit une partie de ton abri.", losses: { mood: 1, food: 1, wood: 1 }, type: "bad", condition: () => game.buildings.indexOf("Abri") > -1 },
  { text: "Un bande de rats mange tes provisions.", losses: { food: 2 }, type: "bad" },
  { text: "Tu t'écorche le pied en marchant sur une pierre.", losses: { mood: 1 }, type: "bad" },
  { text: "La solitude te pèse.", losses: { mood: 1 }, type: "bad" },
  { text: "La chaleur est harassante, tu as besoin de boire.", losses: { food: 1 }, type: "bad" },
  { text: "Tu découvre un matériau spécial.", gains: { material: 1 }, type: "good" },
]

let actions = [
  { text: "Fouiller l'épave du bâteau", condition: () => game.day <= 3, action: () => searchShipwreck() },
  { text: "Explorer", condition: () => true, action: () => explore() },
  { text: "Construire", condition: () => getAvailableBuildings(), action: () => construct() },
  { text: "Fabriquer des outils", condition: () => game.buildings.indexOf("Atelier") > -1 && game.resources.wood > 0, action: () => makeTools() },
  { text: "Forger un matériau spécial", condition: () => game.buildings.indexOf("Atelier") > -1 && game.resources.wood >= 5 && game.resources.tools >= 1, action: () => forgeSpecial() },
  { text: "Se reposer", condition: () => game.buildings.indexOf("Abri") > -1, action: () => rest() },
]

let exploreEvents = [
  { text: "Tu trouve un arbre fruitier", gains: { food: 2 } },
  { text: "Tu trouve une tas de bois", gains: { wood: 3 } },
  { text: "Un serpent t'attaque.", losses: { mood: 1 } },
  { text: "Tu découvre une épave, elle contient un outil.", gains: { tools: 1 } },
  { text: "Tu trébuche sur une racine.", losses: { mood: 1 } },
  { text: "Tu ne trouve rien." },
]

let sleepEvents= [
  { text : "Tu dors à la belle étoile. Des bruits d'animaux t'empêchent de dormir.", condition :()=> game.buildings["Abri"]=-1,losses:{mood:1}},
  { text: "La nuit est glaciale, tu as dû brûler du bois pour survivre.", losses: { wood: 2 } },
  { text: "Tu as bien dormi cette nuit.", gains:{mood:2}}
  ];

let buildings = [
  { name: "Abri", desc: "Coût : 5 bois", cost: { wood: 5 } },
  { name: "Atelier", desc: "Coût : 3 bois", cost: { wood: 3 } },
  { name: "Jardin", desc: "Coût : 3 bois", cost: { wood: 3 } },
  { name: "Puits", desc: "Coût : 3 bois, 1 materiau spécial", cost: { wood: 3, material: 1 } },
  { name: "Palissade", desc: "Coût : 4 bois", cost: { wood: 4 } },
  { name: "Phare", desc: "Coût : 5 bois, 3 materiaux spéciaux, 2 outils", cost: { wood: 5, material: 3, tools: 2 } },
]

window.onload = initGame();

function initGame() {
  console.log("initGame");
  game = {
    day: 0,
    actionsRemaining: 3,
    resources: {
      food: 0,
      wood: 0,
      tools: 0,
      material: 0,
      mood: 5
    },
    buildings: []
  };
  console.log(game);
  refreshResources();
  refreshBuildings();
  logDiv.textContent = "";
  logEvents("Tu te retrouve sur une île deserte. Arriveras-tu à survivre ?")
  dayButtonElement.textContent = "🏝️ Démarrer l'aventure";
  dayElement.textContent = 0;
  nbActionsElement.textContent = 0;
  dayButtonElement.onclick = () => { newDay() };
}

function startDay() {
  game.isDayStarted = true;
  updateDayButton();
  updateRemainingActions(maxActions);
}

function newDay() {
  game.isDayStarted = true;
  updateDayButton();
  game.day++;
  logDiv.textContent = "";
  logEvents("Jour " + game.day);
  dayElement.textContent = game.day;
  if (game.day == 4)
    logEvents("L'épave a fini par sombrer.");
  updateRemainingActions(maxActions);
  launchEvent();
  launchActions();
}

function checkGameState() {
  let isEndGame = false;
  if (game.resources.mood <= 0) {
    isEndGame = true;
  }

  if (isEndGame) {
    dayButtonElement.textContent = "▶️ Nouvelle partie";
    dayButtonElement.onclick = () => { initGame() };
    logEvents("Tu as perdu !");
  }
}

function updateRemainingActions(nb) {
  game.actionsRemaining = nb;
  nbActionsElement.textContent = game.actionsRemaining;
}

function updateDayButton() {
  if (game.isDayStarted === true) {
    dayButtonElement.textContent = "🌙 Fin de journée";
    dayButtonElement.onclick = () => {
      launchConsumption();
    }
  }
  else {
    dayButtonElement.textContent = "🌅 Nouvelle journée";
    dayButtonElement.onclick = () => {
      newDay();
    }
  }
}

function refreshResources() {
  woodElement.textContent = game.resources.wood;
  foodElement.textContent = game.resources.food;
  toolsElement.textContent = game.resources.tools;
  materialElement.textContent = game.resources.material;
  moodElement.textContent = game.resources.mood;
  checkGameState();
}

function refreshBuildings() {
  let buildingsText = game.buildings.join(", ");
  console.log(buildingsText);
  buildingsElement.textContent = buildingsText;
}

function launchDice(max) {
  let dice = Math.random() * max;
  let resultat = Math.floor(dice);
  return resultat;
}

function launchEvent() {
  let randEvent = launchDice(events.length);
  let event = events[randEvent];
  logEvents(event.text);
  if (event.type === "good")
    applyGains(event.gains);
  else if (event.type === "bad")
    applyLoss(event.losses);
  refreshResources();
}

function applyGains(gains) {
  let msgParts = [];

  for (let [key, value] of Object.entries(gains)) {
    game.resources[key] += value;
    msgParts.push("+" + value + " " + getIcon(key));
  }

  logEvents(msgParts.join(', ') + ".", true);
}

function applyLoss(losses) {
  let msgParts = [];

  for (let [key, value] of Object.entries(losses)) {
    let available = game.resources[key] || 0;

    if (available >= value) {
      game.resources[key] -= value;
      msgParts.push(`-${value} ${getIcon(key)}`);
    }
    else if (available > 0) {
      let missing = value - available;
      game.resources[key] = 0;
      game.resources.mood -= missing;
      msgParts.push(`-${available} ${getIcon(key)} et moral -${missing}`);
    }
    else {
      game.resources.mood -= value;
      msgParts.push(`Pas de ${getIcon(key)} ! Moral -${value}`);
    }
  }

  logEvents(`${msgParts.join(", ")}.`, true);
}

function applyResourceChanges(changes, isGain = true) {
  let amount = 0;
  let isUpdated = false;
  let txtState = "";
  for (let [key, value] of Object.entries(changes)) {
    amount = Math.floor(Math.random() * value) + 1;
    if (isGain) {
      txtState = "+";
      if (key == "mood") {
        if (game.resources["mood"] + amount >= maxMood) {
          amount = maxMood - amount;
          game.resources[key] = maxMood;
        }
        else {
          game.resources[key] += amount;
        }
      }
      else {
        game.resources[key] += amount;
      }
      isUpdated = true;
    }
    else {
      txtState = "-";
      if (game.resources[key] - amount >= 0) {
        game.resources[key] -= amount;
      }
      else {
        logEvents(txtState + amount + " " + getIcon(key) + ".", true);
        key = "mood";
        game.resources[key] -= 1;
      };
      isUpdated = true;
    };
    if (isUpdated) {
      logEvents(txtState + amount + " " + getIcon(key) + ".", true);
    }
  };
}

function checkResources(key, isGain = true, amount) {
  if (isGain === false) {
    if (game.resources[key] - amount < 0)
      return false;
    else
      return true;
  }
  else {
    if (key === "mood") {
      if (game.resources["mood"] + amount > maxMood)
        return false;
      else
        return true;
    }
  }
}

function getIcon(key) {
  let name = "";
  switch (key) {
    case "food":
      name = "🍎";
      break;
    case "material":
      name = "💎";
      break;
    case "mood":
      name = "💭";
      break;
    case "tools":
      name = "🛠️";
      break;
    case "wood":
      name = "🌲";
      break;
    default:
      name = "<no name>";
      break;
  }
  return name;
}

function logEvents(message, isResource = false) {
  if (isResource)
    logDiv.innerHTML += `<p class=resmsg>${message}</p>`;
  else
    logDiv.innerHTML += `<p>${message}</p>`;
  console.log(message);
  logDiv.scrollTop = logDiv.scrollHeight;
}

function searchShipwreck() {
  logEvents("Tu fouille l'épave.")
  applyResourceChanges({ food: 2, wood: 3 }, true)
}

function launchActions() {
  selectedActions = [];
  actionChoices.innerHTML = "";
  console.log("Possède Abri " + (game.buildings.indexOf("Abri") > -1));
  actions.forEach(a => {
    if (a.condition()) {
      const btn = document.createElement("button");
      if (a.text === "Construire") {
        showBuildingDropdown();
      }
      else {
        btn.textContent = a.text;
        btn.onclick = () => {
          if (game.actionsRemaining > 0) {
            a.action();
            updateRemainingActions(game.actionsRemaining - 1);
            btn.disabled = true;
          }
        }
        actionChoices.appendChild(btn);
      }
    }
  });
}

function getAvailableBuildings() {
  return buildings.filter(b => canAfford(b));
}

function canAfford(building) {
  console.log(building.name + " " + game.buildings.indexOf(building.name));
  if (game.buildings.indexOf(building.name) > -1)
    return false;

  for (let res in building.cost) {
    if ((game.resources[res] || 0) < building.cost[res]) {
      return false;
    }
  }
  return true;
}

function showBuildingDropdown() {
  nbBuildingsAvailable = 0;
  let select = document.createElement("select");
  buildings.forEach((b, i) => {
    if (canAfford(b)) {
      nbBuildingsAvailable++;
      let option = document.createElement("option");
      option.textContent = "Construire " + b.name;
      option.value = i;
      option.disabled = false;
      select.appendChild(option);
    }
  });
  console.log("Nombre de bâtiments disponibles à la construction : " + nbBuildingsAvailable);
  if (nbBuildingsAvailable > 0) {
    const validateBtn = document.createElement("button");
    validateBtn.textContent = "Construire";
    validateBtn.onclick = () => {
      if (game.actionsRemaining > 0) {
        construct(select.value);
        updateRemainingActions(game.actionsRemaining - 1);
        validateBtn.disabled = true;
      }
    };
    actionChoices.appendChild(select);
    actionChoices.appendChild(validateBtn);
  }
}

function explore() {
  logEvents("🌿 Tu explores les alentours ...");
  let rand = launchDice(exploreEvents.length);
  let event = exploreEvents[rand];
  logEvents(event.text);
  if (event.gains)
    applyResourceChanges(event.gains, true);
  else if (event.losses)
    applyResourceChanges(event.losses, false);
  refreshResources();
}

function construct(idBuilding) {
  let msgParts = [];

  const building = buildings[idBuilding];

  for (let [key, value] of Object.entries(building.cost)) {
    game.resources[key] -= value;
    msgParts.push("-" + value + " " + getIcon(key));
  }
  refreshResources();
  logEvents("Tu as construit : " + building.name)
  logEvents(msgParts.join(', ') + ".", true);

  game.buildings.push(building.name);
  refreshBuildings();
}

function makeTools() {
  game.resources.tools += 1;
  game.resources.wood += 1;
  refreshResources();
  logEvents("Tu fabrique un outil : +1" + getIcon("tools") + ", -1" + getIcon("wood"));
}

function makeTools() {
  game.resources.tools += 1;
  game.resources.wood -= 1;
  refreshResources();
  logEvents("Tu fabrique un outil : +1" + getIcon("tools") + ", -1" + getIcon("wood"));
}

function forgeSpecial() {
  game.resources.material += 1;
  game.resources.wood -= 5;
  game.resources.tools -= 1;
  refreshResources();
  logEvents("Tu fabrique un materiau spécial : +1" + getIcon("material") + ", -5" + getIcon("wood") + ", -1" + getIcon("tools"));
}

function rest() {
  if (game.resources.mood < 5) {
    logEvents("Tu te repose : +1 " + getIcon("mood"));
    game.resources.mood += 1;
    refreshResources();
  }
  else if (game.resources.mood == 5) {
    logEvents("Tu te repose : déjà au max de moral");
  }
}

function launchConsumption() {
  logEvents("C'est l'heure de manger !");
  if (game.resources.food > 0) {
    applyResourceChanges({ food: 1 }, false);
  }
  else {
    logEvents("Malheureusement, tu n'as pas de nourriture !");
    applyResourceChanges({ mood: 1 }, false);
  }
  refreshResources();
  game.isDayStarted = false;
  updateDayButton();
}